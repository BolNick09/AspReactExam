export default function DeadEnd() 
{
    return (
        <>
            <h1>404</h1>
            <div>Page not found</div>
        </>
    )
}